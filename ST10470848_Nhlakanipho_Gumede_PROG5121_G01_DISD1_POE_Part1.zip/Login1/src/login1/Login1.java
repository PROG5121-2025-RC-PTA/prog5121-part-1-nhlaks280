/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login1;


/**
 *
 * @author RC_Student_lab
 */
//public class Login1 {


import javax.swing.JOptionPane;

public class Login1 {
    // Class variables to store user information
    private String username; // Variable to hold the username
    private String password; // Variable to hold the password
    private String cellNumber; // Variable to hold the cell phone number
    private String firstName; // Variable to hold the user's first name
    private String lastName; // Variable to hold the user's last name

    // Constructor to initialize first and last name
    public Login1(String firstName, String lastName) {
        this.firstName = firstName; // Assigning first name to the class variable
        this.lastName = lastName; // Assigning last name to the class variable
    }

    // Method to check if the username is valid
    public boolean checkUserName(String username) {
        // Validates that the username is at most 5 characters long and contains an underscore
        return username.length() <= 5 && username.contains("_");
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        // Ensures the password is at least 8 characters long
        if (password.length() < 8) return false;

        boolean hasCapital = false; // Flag to check for uppercase letters
        boolean hasNumber = false; // Flag to check for numbers
        boolean hasSpecial = false; // Flag to check for special characters

        // Iterates through each character in the password
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true; // Checks for uppercase letters
            else if (Character.isDigit(c)) hasNumber = true; // Checks for digits
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true; // Checks for special characters
        }
        // Returns true if all conditions for a complex password are met
        return hasCapital && hasNumber && hasSpecial;
    }

    // Method to check cell phone number format
    public boolean checkCellPhoneNumber(String cellNumber) {
        // Validates that the cell number matches the South African format
        return cellNumber.matches("^\\+27\\d{9}$");
    }

    // Method to register user
    public String registerUser(String username, String password, String cellNumber) {
        // Validates username, password, and cell number
        boolean validUser = checkUserName(username);
        boolean validPass = checkPasswordComplexity(password);
        boolean validCell = checkCellPhoneNumber(cellNumber);

        // Provides feedback based on validation results
        if (!validUser && !validPass && !validCell) {
            return "Registration failed:\n"
                 + "- Username must contain _ and be ≤5 characters\n"
                 + "- Password needs 8+ chars with capital, number & special char\n"
                 + "- Cell number must be SA format (+27 followed by 9 digits)";
        } else if (!validUser) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!validPass) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else if (!validCell) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        } else {
            // Assigns validated user information to class variables
            this.username = username;
            this.password = password;
            this.cellNumber = cellNumber;
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
        }
    }

    // Method to verify login
    public boolean loginUser(String username, String password) {
        // Checks if the provided username and password match the stored values
        return this.username != null 
               && this.password != null 
               && this.username.equals(username) 
               && this.password.equals(password);
    }

    // Method to return login status message
    public String returnLoginStatus(boolean isLoggedIn) {
        // Returns a welcome message if logged in, otherwise an error message
        return isLoggedIn ? "Welcome " + firstName + " " + lastName + ", it is great to see you again." 
                          : "Username or password incorrect, please try again.";
    }

    // Main method
    public static void main(String[] args) {
        // Prompts user for their first and last name
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        // Creates a new Login1 object with the provided names
        Login1 user = new Login1(firstName, lastName);

        // Registration process
        String username = JOptionPane.showInputDialog("Username:");
        String password = JOptionPane.showInputDialog("Password:");
        String cell = JOptionPane.showInputDialog("SA Cell Number (+27...):");

        // Attempts to register the user and captures the result
        String regResult = user.registerUser(username, password, cell);
        JOptionPane.showMessageDialog(null, regResult);

        // Login if registration succeeded
        if (regResult.contains("successfully")) {
            // Prompts for login credentials
            String loginUser = JOptionPane.showInputDialog("Username:");
            String loginPass = JOptionPane.showInputDialog("Password:");

            // Verifies login credentials
            boolean loggedIn = user.loginUser(loginUser, loginPass);
            // Displays login status message
            JOptionPane.showMessageDialog(null, user.returnLoginStatus(loggedIn));
        }
    }
}