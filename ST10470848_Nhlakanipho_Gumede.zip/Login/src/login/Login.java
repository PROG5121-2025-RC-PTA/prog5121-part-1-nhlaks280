/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login;

/**
 *
 * @author RC_Student_lab
 */
import java.util.regex.Pattern;

public class Login {
    private String username;
    private String password;
    private String cellPhone;

    public boolean checkUserName(String username) {
        this.username = username;
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        this.password = password;
        return password.length() >= 8 && 
               Pattern.compile("[A-Z]").matcher(password).find() && 
               Pattern.compile("[0-9]").matcher(password).find() && 
               Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();
    }

    public boolean checkCellPhoneNumber(String cellPhone) {
        this.cellPhone = cellPhone;
        return cellPhone.matches("\\+27\\d{9}");
    }

    public String registerUser(String username, String password, String cellPhone) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "User successfully registered.";
    }

    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    public String returnLoginStatus(boolean loginSuccess) {
        return loginSuccess ? "Welcome " + username + ", it is great to see you again." : "Username or password incorrect, please try again.";
    }

    public static void main(String[] args) {
        Login login = new Login();
        String registrationMessage = login.registerUser("kyl_1", "Password1!", "+27123456789");
        System.out.println(registrationMessage);
        
        boolean loginSuccess = login.loginUser("kyl_1", "Password1!");
        System.out.println(login.returnLoginStatus(loginSuccess));
    }
}

